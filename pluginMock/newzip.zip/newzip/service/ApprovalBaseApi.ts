/*
 * @Description:
 * @FilePath: \approval\src\service\ApprovalBaseApi.ts
 */
const { NetApi } = require('sslib/netAdapter');
import { getHostUrl } from '@/utils/commonUtil';
import WebJSBridgeImpl from "bankConfig/getAccessToken/BankJSBridgeImpl";
import mineApi from "bankConfig/getAccessToken/mineApi";
const webJSBridgeImpl = new WebJSBridgeImpl();
declare const NativeSupportApi: any;
class ApprovalBaseApi extends NetApi {
    async doGet(url, params, needLogin = true) {
        const host_url = await getHostUrl();
        const complete_url = `${host_url}${url}`;
        console.log('ApprovalBaseApi--------doGet', complete_url);
        return super.doGet(complete_url, params, needLogin);
    }
    async doPost(url, params, needLogin = true) {
        const host_url = await getHostUrl();
        const complete_url = `${host_url}${url}`;
        console.log('ApprovalBaseApi--------doPost', complete_url);
        return super.doPost(complete_url, params, needLogin);
    }
    //重写sinosun-lib里面获取token的方法
    async getToken() {
        const data =  await webJSBridgeImpl.GetLocationAccesstion();
        return {
            accessToken:data
        }
    }

     //重写sinosun-lib里面获取用户信息拼装params的方法
     async dealRequestParams(params = {}, url: string, needLogin = true) {
        if (needLogin) {
            try {
                console.log(url,"接口url")
                console.log(params,"接口params")
                const data = await mineApi.getRequsetInfo();
                const { ebankId, cpyId,userName} = data;
                console.log('重写的dealRequestParams方法---------',params)
                return (<any>Object).assign({}, {
                    userId: ebankId||"",
                    userName:userName || ``,
                    companyId: cpyId||"",
                }, params)
            } catch (e) {
                console.error('NetApi => api => dealRequestParams === ', e);
                return params;
            }
        } else {
            return params;
        }
    }
}

export default ApprovalBaseApi;
