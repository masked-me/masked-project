/*
 * @Author: caohui
 * @Date: 2020-12-08 16:44:41
 * @LastEditors: caohui
 * @LastEditTime: 2020-12-08 17:28:23
 * @Description: 
 * @FilePath: \bosspay\src\service\transfer.ts
 */


import Api from "./Api";
class TransferService extends Api {
	constructor() {
		super();
	}

	getTemplateInfoByType(params = {}){
		const url = `/ebank/approval/v1/listDetailByCompanyId`;
		const errorMessage = `查询模板信息失败`;
		return this.dealResultPromise(url, params, `Post`, errorMessage)
	}

	queryAccountInfo(params = {}) {
		const url = `/ebank/accountmgmt/v1/queryAccountInfo`;
		const errorMessage = `查询账户信息失败`;
		return this.dealResultPromise(url, params, `Get`, errorMessage)
	}

	transferCharge(params = {}){
		const url = `/ebank/transfer/v1/getChargeAmount`;
		const errorMessage = `获取手续费失败`;
		return this.dealResultPromise(url, params, `Post`, errorMessage)
	}

	/**
	 * 查询企业下设置的所有流程的列表
	 * @param params 
	 * @returns 
	 */
	listFlow(params = {}) {
		const url = `/ebank/flowmgmt/v1/listFlow`;
		const errorMessage = `获取流程失败`;
		return this.dealResultPromise(url, params, `Get`, errorMessage)
	}

	/**
	 * 查询某人所有的角色,keycloak权限
	 * @param result 
	 * @returns 
	 */
	 listSomeoneRole(params = {}) {
		const url = `/ebank/rolemgmt/v1/listSomeoneRole`;
		const errorMessage = `获取角色权限失败`;
		return this.dealResultPromise(url, params, `Get`, errorMessage)
	 }

	/**
	 * 重写BaseApi里面的转换服务器result业务数据到本地的 model对象
	 * @override
	 */
	tranferResultModel(result: any): object {
		return (result as any).result || {};
	}

	// 获取支付单号
	createPayOrder(params = {}) {
		const url = `/bizmate/bosspay/v1/createPayOrder`;
		const errorMessage = `获取支付单号失败`;
		return this.dealResultPromise(url, params, `Post`, errorMessage);
	}
}

export default new TransferService();
