/*
 * @Autor: fengzh
 * @Description:密码器管理服务接口类
 * @Date: 2020-08-24 10:50:32
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-12-02 22:32:07
 * @FilePath: \approval\src\service\WdssApi.ts
 */
import { SnToast } from 'sinosun-ui';
// const { NetApi } = require('sslib/netAdapter');
import ApprovalBaseApi from './ApprovalBaseApi';

class WdssApi extends ApprovalBaseApi {
    /**
     * @description: 查询企业下安全硬件列表
     * @param {type}
     */
    queryMCodeUserList(params: object): Promise<object> {
        return new Promise((res, rej) => {
            this.doGet('/ebank/wdss/v1/findUkeyByCstNo', params)
                .then((result) => {
                    res((result as any).result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    /**
     * @description: 查询角色列表对应的用户
     * @param {type}
     */
    listRoleUser(params: object): Promise<object> {
        return new Promise((res, rej) => {
            this.doPost('/ebank/rolemgmt/v1/listRoleUser', params)
                .then((result) => {
                    res((result as any).result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    /**
     * @description: 查询用户权限
     * @param {type}
     */
    findOwnedAuth(params: object): Promise<object> {
        return new Promise((res, rej) => {
            this.doPost('/ebank/authority/v1/listPermissionByUser', params)
                .then((result) => {
                    res((result as any).result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }

    /**
     * @abstract 提示异常信息，业务api内部可重写决定
     * @param url
     * @param msg
     */
    showMessage(url: string, msg: string) {
        if (!url.includes('getTfkeyListForCompany')) SnToast(msg);
    }
}
export default new WdssApi();
