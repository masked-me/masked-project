/*
 * @Author: caohui
 * @Date: 2020-12-08 16:44:26
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2021-01-07 09:59:42
 * @Description: mock数据开关
 * @FilePath: \bosspay\src\service\netConfig.ts
 */


//mock数据开关
export const localDev = false;

