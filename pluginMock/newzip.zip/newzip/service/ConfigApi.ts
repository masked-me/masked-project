/*
 * @Description:
 * @FilePath: \approval\src\service\ConfigApi.ts
 */
// const { NetApi } = require('sslib/netAdapter');
import ZKConfig from '../config/ZKConfig';
import MSTPConfig from '../config/MSTPConfig';
import AppIDConfig from '../config/AppIDConfig';
import ApprovalBaseApi from './ApprovalBaseApi';
class ConfigApi extends ApprovalBaseApi {
    constructor() {
        super();
    }

    getZKConfig() {
        return new Promise((res, rej) => {
            const bRes = {};
            bRes['result'] = ZKConfig;
            res(bRes);
        });
    }

    getMSTPConfig() {
        return new Promise((res, rej) => {
            const bRes = {};
            bRes['result'] = MSTPConfig;
            res(bRes);
        });
    }

    getAppID(paramList: string[]) {
        return new Promise((res, rej) => {
            const bRes = {};
            bRes['result'] = AppIDConfig;
            res(bRes);
        });
    }
}
export default new ConfigApi();
