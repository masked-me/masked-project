/*
 * @Autor: fengzh
 * @Description: 审批服务接口类
 * @FilePath: \approval\src\service\ApprovalApi.ts
 */
// const { NetApi } = require('sslib/netAdapter');
import FlowId from '../model/FlowId';
import ApplyInfo from '../model/ApplyInfo';
import DetailInfo from '../model/DetailInfo';
import ApprovalInfo from '../model/ApprovalInfo';
import TemplateInfo from '../model/TemplateInfo';
import ApplyParam from '../model/ApplyParam';
import RecallParam from '../model/RecallParam';
import ApproveParam from '../model/ApproveParam';
import GetListParam from '../model/GetListParam';
import AttenceLeaveDetail from '../model/AttenceLeaveDetail';
import ClassifyList from '../model/IndexTemplateList';
import FilterList from '../model/FilterList';
import AppDetail from '../model/AppDetail';
import UnreadList from '../model/UnreadList';
import FlowList from '../model/FlowList';
import ApprovalBaseApi from './ApprovalBaseApi';

const approvalPrex = '/ebank/swpApproval/v1';

class ApprovalApi extends ApprovalBaseApi {
    constructor() {
        super();
    }

    /**
     * api网络请求,默认是走网络请求
     * @abstract 子类可以继承重写该方法来返回本地假数据用来模拟自测
     * @param url
     * @param params
     * @param header
     * @param method
     */
    request(url: string, params: object, method: string): Promise<object> {
        return this[`do${method}`](url, params);
    }

    //查询表单id，页面刷新后就会查询
    getFlowId(): Promise<object> {
        return new Promise((res, rej) => {
            this.doGet(`${approvalPrex}/getNewFlowId`, {})
                .then((result) => {
                    if (result.result) {
                        result.result = new FlowId(result.result);
                    }
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    //获取表单申请时信息  字段信息/列表信息等
    getApplyInfo(
        cpyTempletId: number,
        templetType: number,
        appletUAId: number,
        prodId: number
    ): Promise<object> {
        return new Promise((res, rej) => {
            this.request(
                `${approvalPrex}/getApplyInfo`,
                { cpyTempletId, templetType, appletUAId, prodId },
                'Get'
            )
                .then((result: any) => {
                    if (result.result) {
                        result.result = new ApplyInfo(result.result);
                    }
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    //获取表单详情时信息
    getDetailInfo(
        templetType: number,
        appletUAId: number,
        prodId: number,
        flowId: number
    ): Promise<object> {
        return new Promise((res, rej) => {
            this.request(
                `${approvalPrex}/getDetailInfo`,
                { templetType, appletUAId, prodId, flowId },
                'Get'
            )
                .then((result: any) => {
                    if (result.result) {
                        result.result = new DetailInfo(result.result);
                    }
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    //获取表单审批时信息
    getApproveInfo(
        templetType: number,
        appletUAId: number,
        prodId: number,
        flowId: number
    ): Promise<object> {
        return new Promise((res, rej) => {
            this.request(
                `${approvalPrex}/getApproveInfo`,
                { templetType, appletUAId, prodId, flowId },
                'Get'
            )
                .then((result: any) => {
                    if (result.result) {
                        result.result = new ApprovalInfo(result.result);
                    }
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    //自审自批
    applyAndApprove(param: any): Promise<object> {
        const applyParam = new ApplyParam(param);
        console.log(applyParam);
        return new Promise((res, rej) => {
            // this.request(`${approvalPrex}/applyAndApprove`, applyParam, 'Post')
            this.request(`${approvalPrex}/applyAndApprove`, applyParam, 'Post')
                .then((result) => {
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    //表单审批
    approve(param: any): Promise<object> {
        const approveParam = new ApproveParam(param); //genFlowData
        return new Promise((res, rej) => {
            this.request(`${approvalPrex}/approve`, approveParam, 'Post')
                .then((result) => {
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    //表单申请
    apply(param: any): Promise<object> {
        const applyParam = new ApplyParam(param);
        return new Promise((res, rej) => {
            this.request(`${approvalPrex}/apply`, applyParam, 'Post')
                .then((result) => {
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    //查询审批列表
    getList(param: any): Promise<object> {
        const getListParam = new GetListParam(param);
        // const getListParam = {
        //     flowTypeList:[1],
        //     pageNum:1,
        //     pageSize:5,
        //     flowSourceType:1,
        
        // }
        return new Promise((res, rej) => {
            this.request(`${approvalPrex}/getFlowList`, getListParam, 'Post')
                .then((result: any) => {
                    if (result.result) {
                        result.result = new FlowList(result.result);
                    }
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    //获取未读数
    getUnreadList(appletUAId: number): Promise<object> {
        return new Promise((res, rej) => {
            this.request(`${approvalPrex}/getUnreadList`, { appletUAId }, 'Get')
                .then((result: any) => {
                    if (result.result) {
                        result.result = new UnreadList(result.result);
                    }
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    //获取模板数据
    getTemplateInfo(
        cpyTempletId: number,
        templetType: number,
        appletUAId: number,
        flowId: number,
        prodId: number
    ): Promise<object> {
        return new Promise((res, rej) => {
            this.request(
                `${approvalPrex}/getTemplateInfo`,
                {
                    cpyTempletId,
                    templetType,
                    appletUAId,
                    flowId,
                    prodId,
                },
                'Get'
            )
                .then((result: any) => {
                    if (result.result && result.result['templetInfo']) {
                        result.result['templetInfo'] = new TemplateInfo(
                            result.result['templetInfo']
                        );
                    }
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    //获取首页模板列表
    getTempletList(appletUAId: number, prodId: number): Promise<object> {
        return new Promise((res, rej) => {
            this.request(
                `${approvalPrex}/getIndexTempletList`,
                {
                    appletUAId,
                    prodId,
                },
                'Get'
            )
                .then((result: any) => {
                    if (result.result) {
                        result.result = new ClassifyList(result.result);
                    }
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    //查询审批流程列表
    queryUserFlowList(
        applyUaId: number,
        cpyTempletId: number
    ): Promise<object> {
        return new Promise((res, rej) => {
            this.request(
                `${approvalPrex}/queryUserFlowList`,
                {
                    applyUaId,
                    cpyTempletId,
                },
                'Get'
            )
                .then((result) => {
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    //获取确认数据(审批)
    queryDetermineData(
        cpyTempletId: number,
        flowId: number,
        bisData: object
    ): Promise<object> {
        return new Promise((res, rej) => {
            this.doPost(
                ///'/bizmate/approval/v1/checkDetermine',
                `${approvalPrex}/checkDetermine`,
                {
                    cpyTempletId,
                    flowId,
                    bisData,
                }
            )
                .then((result) => {
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    //表单撤销申请
    recall(param: any): Promise<object> {
        const recallParam = new RecallParam(param);
        return new Promise((res, rej) => {
            this.request(`${approvalPrex}/recall`, recallParam, 'Post')
                .then((result) => {
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    //表单撤回审批
    approveRecall(param: any): Promise<object> {
        const recallParam = new RecallParam(param);
        return new Promise((res, rej) => {
            this.request(`${approvalPrex}/approveRecall`, recallParam, 'Post')
                .then((result) => {
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    //获取表单详情所需content信息
    getDetailContent(flowId: number): Promise<object> {
        return new Promise((res, rej) => {
            this.doGet(`${approvalPrex}/getDetailContent`, { flowId })
                .then((result) => {
                    if (result.result) {
                        result.result = new AttenceLeaveDetail(result.result);
                    }
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    //一键已读功能
    markReadAll(appletUAId: number, flowType: number): Promise<object> {
        return new Promise((res, rej) => {
            this.request(
                `${approvalPrex}/markReadAll`,
                {
                    appletUAId,
                    flowType,
                },
                'Post'
            )
                .then((result) => {
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    //查询列表筛选模板
    queryfilterTempletIdList(
        appletUAId: number,
        prodId: number,
        searchParam: object,
        flowTypeList: number[]
    ): Promise<object> {
        return new Promise((res, rej) => {
            this.request(
                `${approvalPrex}/queryfilterTempletIdList`,
                {
                    appletUAId,
                    prodId,
                    searchParam,
                    flowTypeList,
                },
                'Post'
            )
                .then((result: any) => {
                    if (result.result) {
                        result.result = new FilterList(result.result);
                    }
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    //打开详情页面的中转方法
    // openChat(): Promise<object> {
    //     let param = {};
    //     return new Promise((res, rej) => {
    //         this.doPost('approval/applyAndApprove.do', param).then(result => {
    //             res(result)
    //         }).catch(error => {
    //             rej(error);
    //         });
    //     });
    // }
    //获取app详情
    queryAppDetail(
        appName: string,
        UAId: number,
        cpyId: number
    ): Promise<object> {
        return new Promise((res, rej) => {
            this.request(`${approvalPrex}/queryDetail`, { appName }, 'Post')
                .then((result: any) => {
                    if (result.result) {
                        result.result = new AppDetail(result.result);
                    }
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    //获取凭证详情信息（前端发起的请求,银行通知过来查询的）
    getBisInfo(flowId: number, bisData: object): Promise<object> {
        return new Promise((res, rej) => {
            this.request(
                `${approvalPrex}/getBisInfo`,
                {
                    flowId,
                    bisData,
                },
                'Post'
            )
                .then((result) => {
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    //重新发起launchBis方法（审批统一）
    reLaunchBis(params): Promise<object> {
        return new Promise((res, rej) => {
            this.request(`${approvalPrex}/reLaunchBis`, params, 'Post')
                .then((result) => {
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    //获取签名(审批)
    getSignData(
        payInfo: object,
        cpyTempletId: number,
        flowId: number,
        bisData: object
    ): Promise<object> {
        const param = { payInfo, cpyTempletId, flowId, bisData };
        return new Promise((res, rej) => {
            this.request(`${approvalPrex}/getSign`, param, 'Post')
                .then((result) => {
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    /**
     * 表单数据打印
     */
    print(params: object): Promise<object> {
        return new Promise((res, rej) => {
            this.request(`${approvalPrex}/print`, params, 'Post')
                .then((result) => {
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }

    //商城业务参数签名
    signData(param: any): Promise<object> {
        return new Promise((res, rej) => {
            this.request(`${approvalPrex}/signData`, param, 'Post')
                .then((result) => {
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    /**
     * 去后端查询重定向页面，跳转
     * @param param
     */
    openDetail(param: any): Promise<object> {
        return new Promise((res, rej) => {
            this.request(`${approvalPrex}/openDetail`, param, 'Post')
                .then((result) => {
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }

    /**
     * @description: 核查审批链人员是否有权限
     */
    checkPermission(params: any): Promise<object> {
        return new Promise((res, rej) => {
            this.request(`${approvalPrex}/checkPermission`, params, 'Post')
                .then((result) => {
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    /**
     * @description: 查询有权限的审批人
     */
    queryPermissionList(params: any): Promise<object> {
        return new Promise((res, rej) => {
            this.request(`${approvalPrex}/queryPermission`, params, 'Post')
                .then((result) => {
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }

    showMessage(url, msg) { }

    transferBisErrorCode(resultCode: number): string {
        // 先从业务插件中查找错误码，如果业务处理了，直接返回
        const desc =
            (window as any).businessPlugin &&
            (window as any).businessPlugin.transferBisErrorCode &&
            (window as any).businessPlugin.transferBisErrorCode(resultCode, '');
        if (desc) {
            return desc;
        }
        switch (resultCode) {
            case 80109306:
                return '您没有老板付审批权限';
            case 80100001:
            case 80100002:
            case 80100004:
            case 80100005:
            case 80100007:
            case 80100100:
                return '参数错误';
            case 80100106:
                return '表单不存在或已删除';
            case 80100211:
            case 80100200:
                return '该流程不存在,请重新查询';
            case 80100201:
                return '该流程已经完结了,不能再进行操作';
            case 80100202:
                return '您不是该流程的当前操作者';
            case 80100203:
                return '下载附件出错';
            case 80100204:
                return '上传附件出错';
            case 80100205:
                return '获取最新处理人出错';
            case 80100208:
                return '表单不能转交给自己';
            case 80100210:
            case 80100214:
            case 80100215:
            case 80100226:
                return '查找流程信息出错';
            case 80100216:
                return '该流程尚未完结';
            case 80100220:
                return '当前流程不能被完结';
            case 80100222:
                return '表单id重复，请刷新后再重试';
            case 80100224:
                return '创建流程错误';
            case 80100225:
                return '审批流程错误';
            case 80100227:
                return '您不是流程申请人';
            case 80100228:
                return '流程当前不能进行撤回操作';
            case 80100229:
                return '该表单已被审批，无法再进行撤回';
            case 80100230:
                return '该表单已完结，无法再进行撤销';
            case 80100231:
                return '该表单已被撤销，无法再进行审批';
            case 80100233:
                return '该表单已完结，无法进行撤回';
            case 80100234:
                return '该表单已被审批，无法进行撤销';
            case 80100235:
                return '表单已被锁定，无法进行撤销';
            case 80100003:
            case 80100236:
                return '签名信息校验失败';
            case 80100239:
                return '一键已读出错';
            case 80100241:
                return '企业模板不存在';
            case 80100242:
                return '表单审批操作错误，请稍后重试';
            case 80100243:
                return '用户不是流程的申请人';
            case 80100247:
                return '没有找到企业审批模式流程';
            case 80100248:
                return '没有找到金额所对应的企业审批模式流程';
            case 80100249:
                return '没有找到经办人分级信息';
            case 80100250:
                return '没有找到审批人分级信息';
            case 80100251:
                return '没有找到分级对应的人员列表';
            case 80100252:
                return '当前处理人不在分级对应的人员列表中';
            case 80100253:
                return '没有找到企业审批模式';
            case 80100255:
                return '下一个审批处理人不在下一审批分级列表中';
            case 80100257:
                return '当前经办人不在分级对应的人员列表中';
            case 80100258:
                return '流程没有配置分级信息';
            case 80100259:
                return '流程没有配置申请人节点信息';
            case 80100260:
                return '流程没有配置申请人节点下用户列表';
            case 80100261:
                return '流程配置的申请人节点下查询不到用户列表';
            case 80100262:
                return '申请人节点中不包含该用户';
            case 80100263:
                return '没有查询到当前流程的节点';
            case 80100264:
                return '没有查询到当前流程节点下的用户';
            case 80100265:
                return '没有查询到企业流程审批模式的配置信息';
            case 80100266:
                return '流程审批错误';
            case 80100267:
                return '审批额度不足';
            case 80108122:
                return '账户余额不足';
            default:
                return '';
        }
    }
}

export default new ApprovalApi();
