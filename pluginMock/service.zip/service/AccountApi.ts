/*
 * @Autor: fengzh
 * @Description: 账户管理服务接口类
 * @Date: 2020-08-24 10:50:32
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-12-02 22:26:34
 * @FilePath: \approval\src\service\AccountApi.ts
 */
// const { NetApi } = require('sslib/netAdapter');
import { SnToast } from 'sinosun-ui';
import ApprovalBaseApi from './ApprovalBaseApi';
class AccountApi extends ApprovalBaseApi {
    /**
     * @description: 查询付方账号列表
     * @param {type}
     */
    queryAccountList(params): Promise<object> {//todo 后面要改
        return new Promise((res, rej) => {
            this.doPost('/ebank/accountmgmt/v1/queryUserBindAccounts', params)
                .then((result) => {
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    /**
     * @description: 查询常用账号
     * @param {type}
     */
    replaceCommonlyUsedAccount(params): Promise<object> {
        return new Promise((res, rej) => {
            this.doPost(
                '/ebank/accountmgmt/v1/replaceCommonlyUsedAccount',
                params
            )
                .then((result) => {
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    /**
     * @description: 查询银行卡所属银行信息
     * @param {type}
     */
    queryCardBelongBank(params): Promise<object> {
        return new Promise((res, rej) => {
            this.doGet('/ebank/accountmgmt/v1/queryCardBelongBank', params)
                .then((result) => {
                    res(result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    /**
     * @abstract 提示异常信息，业务api内部可重写决定
     * @param url
     * @param msg
     */
    showMessage(url: string, msg: string) {
        if (!url.includes('queryCardBelongBank')) SnToast(msg);
    }
}

export default new AccountApi();
