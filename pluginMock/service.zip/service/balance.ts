/*
 * @Author: caohui
 * @Date: 2020-12-11 16:59:36
 * @LastEditors: caohui
 * @LastEditTime: 2020-12-15 15:02:45
 * @Description:
 * @FilePath: \financial\src\service\financial.ts
 */

import Api from "./Api";
class BalanceService extends Api {
    constructor() {
        super();
    }

    /**
     * 重写BaseApi里面的转换服务器result业务数据到本地的 model对象
     * @override
     */
    tranferResultModel(result: any): object {
        return (result as any).result || {};
    }
    
    // 对账单结果详情
    queryCorpStatementResult(params = {}) {
        const url = `/ebank/balance/v1/queryCorpStatementResult`;
        const errorMessage = `获取对账单结果详情失败`;
        return this.dealResultPromise(url, params, `Get`, errorMessage);
    }
    // 查询对账单列表
    queryCorpStatementDetail(params = {}) {
        const url = `/ebank/balance/v1/queryCorpStatementDetail`;
        const errorMessage = `获取对账单详情失败`;
        return this.dealResultPromise(url, params, `Get`, errorMessage);
    }
    // 查询对账单列表
    queryCorpStatementList(params = {}) {
        const url = `/ebank/balance/v1/queryCorpStatementList`;
        const errorMessage = `获取对账单列表失败`;
        return this.dealResultPromise(url, params, `Get`, errorMessage);
    }
    /**
     * @description: 查询付方账号列表
     * @param {type}
     */
    queryAccountList(params = {}) {
        // params["companyId"]="ecc516b2";
        console.log(params, "queryAccountList");
        const url = `/ebank/accountmgmt/v1/querySignedAccountList`;
        const errorMessage = `获取账号列表失败`;
        return this.dealResultPromise(url, params, `Get`, errorMessage);

    }
    /**
	 * 查询企业下设置的所有流程的列表
	 * @param params 
	 * @returns 
	 */
	listFlow(params = {}) {
		const url = `/ebank/flowmgmt/v1/listFlow`;
		const errorMessage = `获取流程失败`;
		return this.dealResultPromise(url, params, `Get`, errorMessage)
	}
    //查询模板信息
    getTemplateInfoByType(params = {}){
		const url = `/ebank/approval/v1/listDetailByCompanyId`;
		const errorMessage = `失败`;
		return this.dealResultPromise(url, params, `Post`, errorMessage)
	}
    /**
	 * 查询某人所有的角色,keycloak权限
	 * @param result 
	 * @returns 
	 */
	listSomeoneRole(params = {}) {
		const url = `/ebank/rolemgmt/v1/listSomeoneRole`;
		const errorMessage = `获取角色权限失败`;
		return this.dealResultPromise(url, params, `Get`, errorMessage)
	}

}

export default new BalanceService();