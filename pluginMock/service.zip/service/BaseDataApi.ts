/*
 * @Autor: fengzh
 * @Description: 基础数据字典服务接口类
 * @Date: 2020-08-24 10:50:32
 * @LastEditors: Please set LastEditors
 * @LastEditTime: 2020-12-02 22:28:05
 * @FilePath: \approval\src\service\BaseDataApi.ts
 */
// const { NetApi } = require('sslib/netAdapter');
import ApprovalBaseApi from './ApprovalBaseApi';

class BaseDataApi extends ApprovalBaseApi {
    /**
     * @description: 查询银行列表
     * @param {type}
     */
    listBankMembers(): Promise<object> {
        return new Promise((res, rej) => {
            this.doGet('/ebank/basedata/v1/listBankMembers', {})
                .then((result) => {
                    res((result as any).result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
    /**
     * @description: 查询支行列表
     * @param {type}
     */
    getDictData(parms): Promise<object> {
        return new Promise((res, rej) => {
            this.doGet('/ebank/basedata/v1/getDictData', parms)
                .then((result) => {
                    res((result as any).result);
                })
                .catch((error) => {
                    rej(error);
                });
        });
    }
}

export default new BaseDataApi();
